<?php
   

    class Alumno extends Persona
    {

    }


?>