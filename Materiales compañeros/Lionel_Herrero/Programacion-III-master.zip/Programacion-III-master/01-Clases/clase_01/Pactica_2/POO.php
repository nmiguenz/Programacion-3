<?php
    require_once "./Clases/persona.php";
    require_once "./Clases/alumno.php";
    

    $alumno = new Alumno("Juan");

    $alumno->saludar();
  

    


?>

