<?php
    $x = -3;
    $y = 15;


    echo "x = ", $x;
    echo "<br>y = ", $y;
    echo "<br>Resultado: ", $x + $y;
    

?>