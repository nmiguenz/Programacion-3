<?php

    $suma = 0;

    for($i = 1; $suma <= 1000; $i++)
    {
        $suma = $suma + $i;
        echo "<br/>", $suma;
    }

    echo "<br/>Numeros sumados = ", $i - 1;


?>