<?php
    $x = -3;
    $y = 15;

    print($x+$y);
    echo $x + $y;



?>