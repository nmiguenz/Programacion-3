<?php
    
    $nombre = "Lionel";
    $apellido = "Herrero";

    print($apellido.", ".$nombre);

?>

